<?php

class Lumine_Sequence_Exception extends Exception
{
	function __construct($message)
	{
		parent::__construct($message);
	}
}

?>