<?php

require_once LUMINE_INCLUDE_PATH . '/lib/Sequence/ISequence.php';

class Lumine_Sequence_MySQL implements Lumine_Sequence_ISequence {
	
	public function __construct(Lumine_Base $obj)
	{
	}
	
	public function nextID()
	{
	}
	
	public function lastID()
	{
	}
	
	public function getSequence()
	{
	}
	
	public function dropSequence()
	{
	}

	public function createSequence()
	{
	}

	
}


?>